"""
tkinter_auction.py

A Tkinter-based Vehicle Auction System using SQLite.
- Users can register, login, place bids, view notifications.
- Admin users can add vehicles.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime

DB_NAME = 'auction.db'

# -------------------------------------------------------------------------
# Database Initialization
# -------------------------------------------------------------------------
def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        balance REAL DEFAULT 0.0,
        is_admin BOOLEAN DEFAULT FALSE
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        make TEXT NOT NULL,
        model TEXT NOT NULL,
        year INTEGER NOT NULL,
        mileage INTEGER NOT NULL,
        description TEXT,
        reserve_price REAL NOT NULL,
        end_time TEXT NOT NULL,
        seller_id INTEGER NOT NULL,
        FOREIGN KEY (seller_id) REFERENCES users(id)
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS bids (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount REAL NOT NULL,
        time TEXT NOT NULL,
        bidder_id INTEGER NOT NULL,
        vehicle_id INTEGER NOT NULL,
        FOREIGN KEY (bidder_id) REFERENCES users(id),
        FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        message TEXT NOT NULL,
        time TEXT NOT NULL,
        is_read BOOLEAN DEFAULT FALSE,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )
    ''')

    # Create an admin user if not exists
    cursor.execute("SELECT * FROM users WHERE username='admin'")
    if not cursor.fetchone():
        cursor.execute('''
        INSERT INTO users (username, password, email, is_admin)
        VALUES (?, ?, ?, ?)
        ''', ('admin', 'admin123', 'admin@auction.com', True))
    
    conn.commit()
    conn.close()

# -------------------------------------------------------------------------
# Models (User, Vehicle, Bid, Notification)
# -------------------------------------------------------------------------
class User:
    def __init__(self, row):
        """ row is a tuple like: (id, username, password, email, balance, is_admin) """
        self.id = row[0]
        self.username = row[1]
        self.password = row[2]
        self.email = row[3]
        self.balance = row[4]
        self.is_admin = bool(row[5])

    @staticmethod
    def find_by_username(username):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        row = cursor.fetchone()
        conn.close()
        if row:
            return User(row)
        return None

    @staticmethod
    def create_user(username, password, email):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO users (username, password, email)
            VALUES (?, ?, ?)
        ''', (username, password, email))
        conn.commit()
        conn.close()

class Vehicle:
    def __init__(self, row):
        """
        row: (id, make, model, year, mileage, description,
              reserve_price, end_time, seller_id)
        """
        self.id = row[0]
        self.make = row[1]
        self.model = row[2]
        self.year = row[3]
        self.mileage = row[4]
        self.description = row[5]
        self.reserve_price = row[6]
        self.end_time = row[7]
        self.seller_id = row[8]

    @staticmethod
    def get_all_active():
        """Return vehicles where end_time is in the future."""
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute('''
        SELECT * FROM vehicles
        WHERE datetime(end_time) > datetime('now')
        ORDER BY datetime(end_time)
        ''')
        rows = cursor.fetchall()
        conn.close()
        return [Vehicle(r) for r in rows]

    @staticmethod
    def add_vehicle(make, model, year, mileage, desc, reserve_price, end_time, seller_id):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO vehicles (make, model, year, mileage, description,
                                  reserve_price, end_time, seller_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (make, model, year, mileage, desc, reserve_price, end_time, seller_id))
        conn.commit()
        conn.close()

    @staticmethod
    def get_by_id(vehicle_id):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM vehicles WHERE id=?", (vehicle_id,))
        row = cursor.fetchone()
        conn.close()
        if row:
            return Vehicle(row)
        return None

class Bid:
    def __init__(self, row):
        """
        row: (id, amount, time, bidder_id, vehicle_id)
        """
        self.id = row[0]
        self.amount = row[1]
        self.time = row[2]
        self.bidder_id = row[3]
        self.vehicle_id = row[4]

    @staticmethod
    def get_highest_for_vehicle(vehicle_id):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute('''
        SELECT * FROM bids
        WHERE vehicle_id=?
        ORDER BY amount DESC
        LIMIT 1
        ''', (vehicle_id,))
        row = cursor.fetchone()
        conn.close()
        if row:
            return Bid(row)
        return None

    @staticmethod
    def place_bid(amount, bidder_id, vehicle_id):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute('''
        INSERT INTO bids (amount, time, bidder_id, vehicle_id)
        VALUES (?, ?, ?, ?)
        ''', (amount, now_str, bidder_id, vehicle_id))
        conn.commit()
        bid_id = cursor.lastrowid
        conn.close()
        return bid_id

class Notification:
    def __init__(self, row):
        """
        row: (id, user_id, message, time, is_read)
        """
        self.id = row[0]
        self.user_id = row[1]
        self.message = row[2]
        self.time = row[3]
        self.is_read = bool(row[4])

    @staticmethod
    def get_for_user(user_id, unread_only=True):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        if unread_only:
            cursor.execute('''
            SELECT * FROM notifications
            WHERE user_id=? AND is_read=FALSE
            ORDER BY time DESC
            ''', (user_id,))
        else:
            cursor.execute('''
            SELECT * FROM notifications
            WHERE user_id=?
            ORDER BY time DESC
            ''', (user_id,))
        rows = cursor.fetchall()
        conn.close()
        return [Notification(r) for r in rows]

    @staticmethod
    def mark_as_read(notification_id):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute('''
        UPDATE notifications
        SET is_read=TRUE
        WHERE id=?
        ''', (notification_id,))
        conn.commit()
        conn.close()

    @staticmethod
    def create_notification(user_id, message):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute('''
        INSERT INTO notifications (user_id, message, time)
        VALUES (?, ?, ?)
        ''', (user_id, message, now_str))
        conn.commit()
        conn.close()

# -------------------------------------------------------------------------
# Main Tkinter Application
# -------------------------------------------------------------------------
class VehicleAuctionApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Vehicle Auction System")
        self.geometry("800x500")
        
        # Session-like data
        self.current_user = None

        # Frames
        self.login_frame = None
        self.register_frame = None
        self.main_frame = None

        # Initialize DB
        init_db()

        # Show login frame on startup
        self.show_login_frame()

    # ---------------------------------------------------------------------
    # Frame Navigation
    # ---------------------------------------------------------------------
    def show_login_frame(self):
        if self.login_frame is not None:
            self.login_frame.destroy()
        if self.register_frame is not None:
            self.register_frame.destroy()
        if self.main_frame is not None:
            self.main_frame.destroy()

        self.login_frame = LoginFrame(self)
        self.login_frame.pack(fill="both", expand=True)

    def show_register_frame(self):
        if self.login_frame is not None:
            self.login_frame.destroy()
        if self.register_frame is not None:
            self.register_frame.destroy()
        if self.main_frame is not None:
            self.main_frame.destroy()

        self.register_frame = RegisterFrame(self)
        self.register_frame.pack(fill="both", expand=True)

    def show_main_frame(self):
        if self.login_frame is not None:
            self.login_frame.destroy()
        if self.register_frame is not None:
            self.register_frame.destroy()
        if self.main_frame is not None:
            self.main_frame.destroy()

        self.main_frame = MainFrame(self)
        self.main_frame.pack(fill="both", expand=True)

# -------------------------------------------------------------------------
# Login Frame
# -------------------------------------------------------------------------
class LoginFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master

        tk.Label(self, text="Login", font=("Arial", 18)).pack(pady=10)

        tk.Label(self, text="Username:").pack()
        self.username_entry = tk.Entry(self)
        self.username_entry.pack()

        tk.Label(self, text="Password:").pack()
        self.password_entry = tk.Entry(self, show="*")
        self.password_entry.pack()

        tk.Button(self, text="Login", command=self.handle_login).pack(pady=5)
        tk.Button(self, text="Register", command=self.master.show_register_frame).pack()

    def handle_login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        
        user = User.find_by_username(username)
        if user and user.password == password:
            self.master.current_user = user
            messagebox.showinfo("Success", f"Welcome, {user.username}!")
            self.master.show_main_frame()
        else:
            messagebox.showerror("Error", "Invalid credentials")

# -------------------------------------------------------------------------
# Register Frame
# -------------------------------------------------------------------------
class RegisterFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master

        tk.Label(self, text="Register", font=("Arial", 18)).pack(pady=10)

        tk.Label(self, text="Username:").pack()
        self.username_entry = tk.Entry(self)
        self.username_entry.pack()

        tk.Label(self, text="Password:").pack()
        self.password_entry = tk.Entry(self, show="*")
        self.password_entry.pack()

        tk.Label(self, text="Email:").pack()
        self.email_entry = tk.Entry(self)
        self.email_entry.pack()

        tk.Button(self, text="Register", command=self.handle_register).pack(pady=5)
        tk.Button(self, text="Back to Login", command=self.master.show_login_frame).pack()

    def handle_register(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        email = self.email_entry.get().strip()

        # Basic checks
        if not username or not password or not email:
            messagebox.showerror("Error", "All fields are required.")
            return

        # Check if user already exists
        existing = User.find_by_username(username)
        if existing:
            messagebox.showerror("Error", "Username already exists.")
            return

        # Create user
        User.create_user(username, password, email)
        messagebox.showinfo("Success", "Registration successful! Please login.")
        self.master.show_login_frame()

# -------------------------------------------------------------------------
# Main Frame
# -------------------------------------------------------------------------
class MainFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.user = self.master.current_user

        # Top bar
        top_frame = tk.Frame(self)
        top_frame.pack(side="top", fill="x")

        welcome_label = tk.Label(top_frame, text=f"Welcome, {self.user.username}!")
        welcome_label.pack(side="left", padx=10, pady=5)

        logout_button = tk.Button(top_frame, text="Logout", command=self.logout)
        logout_button.pack(side="right", padx=10)

        # Notifications
        notif_button = tk.Menubutton(top_frame, text="Notifications", relief=tk.RAISED)
        notif_button.menu = tk.Menu(notif_button, tearoff=0)
        notif_button["menu"] = notif_button.menu

        notifications = Notification.get_for_user(self.user.id, unread_only=True)
        if notifications:
            for n in notifications:
                def mark_read_closure(nid=n.id):
                    return lambda: self.mark_notification_read(nid)
                notif_button.menu.add_command(
                    label=f"{n.message}",
                    command=mark_read_closure()
                )
        else:
            notif_button.menu.add_command(label="No notifications.")
        notif_button.pack(side="right")

        # Main content
        content_frame = tk.Frame(self)
        content_frame.pack(fill="both", expand=True)

        # Admin panel
        if self.user.is_admin:
            admin_frame = tk.LabelFrame(content_frame, text="Admin Panel", padx=10, pady=10)
            admin_frame.pack(side="left", fill="y", padx=10, pady=10)

            tk.Label(admin_frame, text="Add New Vehicle").pack()

            tk.Label(admin_frame, text="Make:").pack()
            self.make_entry = tk.Entry(admin_frame)
            self.make_entry.pack()

            tk.Label(admin_frame, text="Model:").pack()
            self.model_entry = tk.Entry(admin_frame)
            self.model_entry.pack()

            tk.Label(admin_frame, text="Year:").pack()
            self.year_entry = tk.Entry(admin_frame)
            self.year_entry.insert(0, str(datetime.now().year))
            self.year_entry.pack()

            tk.Label(admin_frame, text="Mileage:").pack()
            self.mileage_entry = tk.Entry(admin_frame)
            self.mileage_entry.pack()

            tk.Label(admin_frame, text="Reserve Price:").pack()
            self.reserve_entry = tk.Entry(admin_frame)
            self.reserve_entry.pack()

            tk.Label(admin_frame, text="End Time (YYYY-MM-DD HH:MM:SS):").pack()
            self.endtime_entry = tk.Entry(admin_frame)
            self.endtime_entry.pack()

            tk.Label(admin_frame, text="Description:").pack()
            self.desc_entry = tk.Entry(admin_frame)
            self.desc_entry.pack()

            tk.Button(admin_frame, text="Add Vehicle", command=self.add_vehicle).pack(pady=5)

        # Vehicle list
        vehicles_frame = tk.LabelFrame(content_frame, text="Available Vehicles", padx=10, pady=10)
        vehicles_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        columns = ("id", "make", "model", "year", "mileage", "reserve", "end_time", "highest_bid")
        self.vehicles_tree = ttk.Treeview(vehicles_frame, columns=columns, show='headings')
        for col in columns:
            self.vehicles_tree.heading(col, text=col.capitalize())
        self.vehicles_tree.pack(fill="both", expand=True)

        # Bidding frame (for non-admin)
        if not self.user.is_admin:
            bid_frame = tk.LabelFrame(content_frame, text="Place a Bid", padx=10, pady=10)
            bid_frame.pack(side="left", fill="y", padx=10, pady=10)

            tk.Label(bid_frame, text="Vehicle ID:").pack()
            self.bid_vehicle_id_entry = tk.Entry(bid_frame)
            self.bid_vehicle_id_entry.pack()

            tk.Label(bid_frame, text="Bid Amount:").pack()
            self.bid_amount_entry = tk.Entry(bid_frame)
            self.bid_amount_entry.pack()

            tk.Button(bid_frame, text="Place Bid", command=self.place_bid).pack(pady=5)

        self.load_vehicles()

    def load_vehicles(self):
        """Load active vehicles into the Treeview."""
        # Clear existing rows
        for row in self.vehicles_tree.get_children():
            self.vehicles_tree.delete(row)

        vehicles = Vehicle.get_all_active()
        for v in vehicles:
            highest_bid = Bid.get_highest_for_vehicle(v.id)
            highest_bid_amount = highest_bid.amount if highest_bid else None
            self.vehicles_tree.insert("", "end", values=(
                v.id,
                v.make,
                v.model,
                v.year,
                v.mileage,
                v.reserve_price,
                v.end_time,
                highest_bid_amount
            ))

    def add_vehicle(self):
        make = self.make_entry.get().strip()
        model = self.model_entry.get().strip()
        year = self.year_entry.get().strip()
        mileage = self.mileage_entry.get().strip()
        reserve_price = self.reserve_entry.get().strip()
        end_time = self.endtime_entry.get().strip()
        description = self.desc_entry.get().strip()

        # Basic validations
        if not (make and model and year and mileage and reserve_price and end_time):
            messagebox.showerror("Error", "All fields except description are required.")
            return

        # Insert vehicle into DB
        try:
            Vehicle.add_vehicle(
                make,
                model,
                int(year),
                int(mileage),
                description,
                float(reserve_price),
                end_time,
                self.user.id  # seller_id
            )
            messagebox.showinfo("Success", "Vehicle added successfully!")
            self.load_vehicles()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add vehicle: {e}")

    def place_bid(self):
        vehicle_id_str = self.bid_vehicle_id_entry.get().strip()
        bid_amount_str = self.bid_amount_entry.get().strip()

        if not vehicle_id_str or not bid_amount_str:
            messagebox.showerror("Error", "Vehicle ID and Bid Amount are required.")
            return

        # Validate numeric
        try:
            vehicle_id = int(vehicle_id_str)
            bid_amount = float(bid_amount_str)
        except ValueError:
            messagebox.showerror("Error", "Invalid number input.")
            return

        # Check vehicle
        vehicle = Vehicle.get_by_id(vehicle_id)
        if not vehicle:
            messagebox.showerror("Error", "Vehicle not found.")
            return

        # Check if auction ended
        try:
            vehicle_end = datetime.strptime(vehicle.end_time, '%Y-%m-%d %H:%M:%S')
            if vehicle_end < datetime.now():
                messagebox.showerror("Error", "Auction has ended.")
                return
        except ValueError:
            messagebox.showerror("Error", "Vehicle end_time format invalid in DB.")
            return

        # Check highest bid
        highest_bid = Bid.get_highest_for_vehicle(vehicle_id)
        if highest_bid and bid_amount <= highest_bid.amount:
            messagebox.showerror("Error", "Bid must be higher than the current highest bid.")
            return

        # Check reserve price
        if bid_amount < vehicle.reserve_price:
            messagebox.showerror("Error", "Bid must be at least the reserve price.")
            return

        # Place bid
        Bid.place_bid(bid_amount, self.user.id, vehicle_id)
        messagebox.showinfo("Success", "Bid placed successfully!")
        self.load_vehicles()

        # Notify the seller
        msg = f"New bid of ${bid_amount} placed on your {vehicle.make} {vehicle.model}"
        Notification.create_notification(vehicle.seller_id, msg)

    def logout(self):
        self.master.current_user = None
        self.master.show_login_frame()

    def mark_notification_read(self, notif_id):
        Notification.mark_as_read(notif_id)
        messagebox.showinfo("Notification", "Notification marked as read.")

# -------------------------------------------------------------------------
# Run the Application
# -------------------------------------------------------------------------
if __name__ == "__main__":
    app = VehicleAuctionApp()
    app.mainloop()
